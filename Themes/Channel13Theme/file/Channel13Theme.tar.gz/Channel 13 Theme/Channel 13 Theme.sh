#!/bin/sh
# I Love You, Let's Die - Channel 13 theme: install the skin and select it
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$HOME/skins"
rm -rf "$HOME/skins/ILoveYouLetsDie"
cp -a "$HERE/ILoveYouLetsDie" "$HOME/skins/"
echo "$HOME/skins/ILoveYouLetsDie" > "$HOME/.gameshell_skin"
