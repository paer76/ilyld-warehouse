#!/bin/sh
# Run from the Warehouse (or anywhere): installs Launcher Native (by Paer) as ~/launch-native and switches to it.
exec "$(dirname "$0")/install.sh" "$@"
