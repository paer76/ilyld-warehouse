#!/bin/sh
# Installs Launcher Native (by Paer) as ~/launch-native, adds Utils > "Switch
# Launcher" (in both launchers' menus), and switches to it (reboots).
#   install.sh [--no-switch]
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/launch-native"
OLD="$HOME/launch-cpp"  # where it lived before it was named Launcher Native
if [ "$SRC" != "$DEST" ]; then
	rm -rf "$DEST.new"
	cp -a "$SRC" "$DEST.new"
	for f in sys.cpp/.powerlevel sys.cpp/.buttonslayout; do   # keep its settings
		if [ -f "$DEST/$f" ]; then cp "$DEST/$f" "$DEST.new/$f"
		elif [ -f "$OLD/$f" ]; then cp "$OLD/$f" "$DEST.new/$f"; fi
	done
	rm -rf "$DEST"
	mv "$DEST.new" "$DEST"
fi
# the old name: point it at the new folder (a running session and an older
# ~/.bashrc still use it), and move ~/.bashrc over to the new name
if [ -d "$OLD" ] && [ ! -L "$OLD" ]; then rm -rf "$OLD"; fi
[ -e "$OLD" ] || ln -s launch-native "$OLD"
sed -i 's#~/launch-cpp/\.cpirc#~/launch-native/.cpirc#g' "$HOME/.bashrc"

U="$HOME/apps/Menu/60_Utils"
mkdir -p "$U"
printf '#!/bin/sh\n# Switches between the stock launcher and Launcher Native (reboots).\nexec "$HOME/launch-native/switch_launcher.sh" toggle\n' > "$U/Switch Launcher.sh"
chmod +x "$U/Switch Launcher.sh"
ICONS="$HOME/launcher/skin/default/Menu/GameShell/60_Utils"
if [ -d "$HOME/launcher/skin/default" ]; then
	mkdir -p "$ICONS"
	cp "$DEST/Launcher Native.png" "$ICONS/Switch Launcher.png"
fi
echo "installed: $DEST"
[ "$1" = "--no-switch" ] && exit 0
exec "$DEST/switch_launcher.sh" native
