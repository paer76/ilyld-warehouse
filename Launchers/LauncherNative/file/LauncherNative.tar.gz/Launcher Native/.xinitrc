# X session of Launcher Native (the Python launcher's ~/launcher/.xinitrc,
# with our load.sh; the window manager is still the stock dwm-mod).
session=${1:-gameshell}
WM=/home/cpi/launcher/dwm-mod
# the boot wallpaper: the selected skin's (Settings > Skins), else ours
LOADING=~/launch-native/sys.cpp/gameshell/wallpaper/loading.png
SKIN=$(cat ~/.gameshell_skin 2>/dev/null)
[ -n "$SKIN" ] && [ -f "$SKIN/wallpaper/loading.png" ] && LOADING="$SKIN/wallpaper/loading.png"

case $session in
hdmi )
	[ -x ~/launcher/aria2c ] && ~/launcher/aria2c --conf-path=/home/cpi/launcher/aria2.conf &
	feh --bg-center "$LOADING"
	if [ -x $WM ]; then
		exec ~/launch-native/load.sh &
		exec $WM
	else
		exec ~/launch-native/load.sh
	fi
	;;
gameshell )
	# the Warehouse downloads with aria2c, as in the stock session
	[ -x ~/launcher/aria2c ] && ~/launcher/aria2c --conf-path=/home/cpi/launcher/aria2.conf &
	feh --bg-center "$LOADING"
	if [ -x $WM ]; then
		exec ~/launch-native/load.sh &
		exec $WM -w
	else
		exec ~/launch-native/load.sh
	fi
	;;
*)
	exec $1;;
esac
