#!/bin/sh
# Chooses which launcher the GameShell starts, then reboots into it.
#   switch_launcher.sh native|python|toggle [--no-reboot]     ("cpp" = native)
# Same mechanism as the stock "Switch to LauncherGo": ~/.bashrc sources
# ~/<launcher>/.cpirc, which starts X with that launcher. We rewrite that path.
NATIVE=launch-native
cur=$(grep -oE '~/[A-Za-z0-9_.-]+/\.cpirc' "$HOME/.bashrc" | head -1 | cut -d/ -f2)
[ "$cur" = "launch-cpp" ] && cur=$NATIVE  # its name before it was Launcher Native
case "$1" in
	native|cpp) target=$NATIVE ;;
	python) target=launcher ;;
	toggle|"") if [ "$cur" = "$NATIVE" ]; then target=launcher; else target=$NATIVE; fi ;;
	*) echo "usage: $0 native|python|toggle [--no-reboot]"; exit 2 ;;
esac
if [ ! -f "$HOME/$target/.cpirc" ]; then
	echo "no ~/$target/.cpirc: that launcher is not installed" >&2
	exit 1
fi
[ -f "$HOME/.bashrc.before-launch-cpp" ] || [ -f "$HOME/.bashrc.before-launch-native" ] ||
	cp "$HOME/.bashrc" "$HOME/.bashrc.before-launch-native"
if [ -n "$cur" ]; then
	sed -i -E "s#~/[A-Za-z0-9_.-]+/\.cpirc#~/$target/.cpirc#g" "$HOME/.bashrc"
else
	printf '\nif [ -f ~/%s/.cpirc ]; then\n   . ~/%s/.cpirc\nfi\n' "$target" "$target" >> "$HOME/.bashrc"
fi
if ! grep -q "~/$target/.cpirc" "$HOME/.bashrc"; then
	echo "could not update ~/.bashrc" >&2
	exit 1
fi
echo "next boot: ~/$target (was: ${cur:-none})"
[ "$2" = "--no-reboot" ] && exit 0
DISPLAY="${DISPLAY:-:0}" feh --bg-center "$HOME/$NATIVE/sys.cpp/gameshell/wallpaper/loading.png" 2>/dev/null
sync
sudo reboot
