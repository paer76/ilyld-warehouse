# X session of the C++ launcher (the Python launcher's ~/launcher/.xinitrc,
# with our load.sh; the window manager is still the stock dwm-mod).
session=${1:-gameshell}
WM=/home/cpi/launcher/dwm-mod

case $session in
hdmi )
	feh --bg-center ~/launch-cpp/sys.cpp/gameshell/wallpaper/loading.png
	if [ -x $WM ]; then
		exec ~/launch-cpp/load.sh &
		exec $WM
	else
		exec ~/launch-cpp/load.sh
	fi
	;;
gameshell )
	feh --bg-center ~/launch-cpp/sys.cpp/gameshell/wallpaper/loading.png
	if [ -x $WM ]; then
		exec ~/launch-cpp/load.sh &
		exec $WM -w
	else
		exec ~/launch-cpp/load.sh
	fi
	;;
*)
	exec $1;;
esac
