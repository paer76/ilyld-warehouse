#!/bin/sh
# Run from the Warehouse (or anywhere): installs this launcher as ~/launch-cpp and switches to it.
exec "$(dirname "$0")/install.sh" "$@"
