#!/bin/sh
# Starts the C++ launcher on the GameShell, with the stock launcher's menus
# (~/launcher/Menu and ~/apps/Menu) and skin icons.
# Safety net: if it fails to start 3 times in a row, switch back to the
# Python launcher and reboot, so a broken install can't leave a black screen.
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE/sys.cpp" || exit 1
export DISPLAY="${DISPLAY:-:0}"

set -- --fullscreen "$@"
# launcher 1.25 (stock ClockworkOS) confirms with A and goes back with B
grep -qs IsKeyStartOrA /home/cpi/launcher/sys.py/UI/keys_def.py && set -- "$@" --confirm-a
[ -d /home/cpi/launcher/Menu ] && set -- "$@" --menu /home/cpi/launcher/Menu
[ -d /home/cpi/apps/Menu ] && set -- "$@" --apps-menu /home/cpi/apps/Menu
[ -d /home/cpi/launcher/skin/default ] && set -- "$@" --skin-fallback /home/cpi/launcher/skin/default

fails=0
while :; do
	start=$(date +%s)
	./launcher "$@" >> /tmp/launcher-cpp.log 2>&1
	rc=$?
	[ $rc -eq 0 ] && exit 0          # quit on purpose ("q", or the quit socket command)
	echo "launcher exited with $rc" >> /tmp/launcher-cpp.log
	if [ $(( $(date +%s) - start )) -lt 15 ]; then fails=$((fails + 1)); else fails=0; fi
	if [ $fails -ge 3 ]; then
		echo "failed 3 times: back to the Python launcher" >> /tmp/launcher-cpp.log
		exec "$HERE/switch_launcher.sh" python
	fi
	sleep 1
done
