#!/bin/sh
# Chooses which launcher the GameShell starts, then reboots into it.
#   switch_launcher.sh cpp|python|toggle [--no-reboot]
# Same mechanism as the stock "Switch to LauncherGo": ~/.bashrc sources
# ~/<launcher>/.cpirc, which starts X with that launcher. We rewrite that path.
CPP=launch-cpp
cur=$(grep -oE '~/[A-Za-z0-9_.-]+/\.cpirc' "$HOME/.bashrc" | head -1 | cut -d/ -f2)
case "$1" in
	cpp) target=$CPP ;;
	python) target=launcher ;;
	toggle|"") if [ "$cur" = "$CPP" ]; then target=launcher; else target=$CPP; fi ;;
	*) echo "usage: $0 cpp|python|toggle [--no-reboot]"; exit 2 ;;
esac
if [ ! -f "$HOME/$target/.cpirc" ]; then
	echo "no ~/$target/.cpirc: that launcher is not installed" >&2
	exit 1
fi
[ -f "$HOME/.bashrc.before-launch-cpp" ] || cp "$HOME/.bashrc" "$HOME/.bashrc.before-launch-cpp"
if [ -n "$cur" ]; then
	sed -i -E "s#~/[A-Za-z0-9_.-]+/\.cpirc#~/$target/.cpirc#g" "$HOME/.bashrc"
else
	printf '\nif [ -f ~/%s/.cpirc ]; then\n   . ~/%s/.cpirc\nfi\n' "$target" "$target" >> "$HOME/.bashrc"
fi
if ! grep -q "~/$target/.cpirc" "$HOME/.bashrc"; then
	echo "could not update ~/.bashrc" >&2
	exit 1
fi
echo "next boot: ~/$target (was: ${cur:-none})"
[ "$2" = "--no-reboot" ] && exit 0
DISPLAY="${DISPLAY:-:0}" feh --bg-center "$HOME/launch-cpp/sys.cpp/gameshell/wallpaper/loading.png" 2>/dev/null
sync
sudo reboot
