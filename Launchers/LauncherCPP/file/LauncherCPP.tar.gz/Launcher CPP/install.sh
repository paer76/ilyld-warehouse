#!/bin/sh
# Installs this folder as ~/launch-cpp, adds Utils > "Switch Launcher" (in both
# launchers' menus), and switches to the C++ launcher (reboots).
#   install.sh [--no-switch]
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/launch-cpp"
if [ "$SRC" != "$DEST" ]; then
	rm -rf "$DEST.new"
	cp -a "$SRC" "$DEST.new"
	for f in sys.cpp/.powerlevel sys.cpp/.buttonslayout; do   # keep its settings
		[ -f "$DEST/$f" ] && cp "$DEST/$f" "$DEST.new/$f"
	done
	rm -rf "$DEST"
	mv "$DEST.new" "$DEST"
fi
U="$HOME/apps/Menu/60_Utils"
mkdir -p "$U"
printf '#!/bin/sh\n# Switches between the Python and the C++ launcher (reboots).\nexec "$HOME/launch-cpp/switch_launcher.sh" toggle\n' > "$U/Switch Launcher.sh"
chmod +x "$U/Switch Launcher.sh"
ICONS="$HOME/launcher/skin/default/Menu/GameShell/60_Utils"
if [ -d "$HOME/launcher/skin/default" ]; then
	mkdir -p "$ICONS"
	cp "$DEST/Launcher CPP.png" "$ICONS/Switch Launcher.png"
fi
echo "installed: $DEST"
[ "$1" = "--no-switch" ] && exit 0
exec "$DEST/switch_launcher.sh" cpp
