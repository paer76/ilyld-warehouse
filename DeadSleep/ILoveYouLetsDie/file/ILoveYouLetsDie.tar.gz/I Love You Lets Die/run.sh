#!/bin/sh
# Starts the game on the GameShell (its own SDL3 next to it; the screen the launcher's X server).
cd "$(dirname "$0")"
export LD_LIBRARY_PATH="$PWD/lib:$LD_LIBRARY_PATH"
export DISPLAY="${DISPLAY:-:0}"
exec ./ILoveYouLetsDie "$@"
