#!/bin/sh
# I Love You, Let's Die - started by the GameShell launcher (Warehouse), or from anywhere
exec "$(dirname "$0")/run.sh" "$@"
